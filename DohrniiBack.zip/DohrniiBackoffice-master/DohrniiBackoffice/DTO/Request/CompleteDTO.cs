﻿namespace DohrniiBackoffice.DTO.Request
{
    public class CompleteDTO
    {
        public int Id { get; set; }
    }
}
