﻿namespace DohrniiBackoffice.DTO.Request
{
    public class StartDTO
    {
        public int Id { get; set; }
    }
}
