﻿namespace DohrniiBackoffice.DTO.Request
{
    public class EmailCodeDTO
    {
        public string Email { get; set; }
        public string? Region { get; set; }
        public string? Device { get; set; }
    }
}
