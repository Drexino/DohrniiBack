﻿namespace DohrniiBackoffice.DTO.Response
{
    public class RegisterResponse
    {
        public bool Success { get; set; }
        public string ErrorMessage { get; set; }
    }
}
