﻿namespace DohrniiBackoffice.DTO.Response
{
    public class ErrorResponse
    {
        public string Details { get; set; }
    }
}
