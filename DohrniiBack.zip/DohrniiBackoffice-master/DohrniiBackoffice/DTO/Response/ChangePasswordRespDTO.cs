﻿namespace DohrniiBackoffice.DTO.Response
{
    public class ChangePasswordRespDTO
    {
        public string Message { get; set; }
        public bool IsSuccessful { get; set; }
    }
}
