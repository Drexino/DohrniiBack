﻿namespace DohrniiBackoffice.DTO.Response
{
    public class StartResponseDTO
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public bool IsStarted { get; set; }
    }
}
