﻿namespace DohrniiBackoffice.Models
{
    public class LoginModel
    {
        public string Email { get; set; }
        public string password { get; set; }
        public string ReturnUrl { get; set; }
    }
}
