﻿namespace DohrniiBackoffice.Models.Emails
{
    public class WelcomeMail
    {
        public string? Name { get; set; }
        public string? Email { get; set; }
        public string? Code { get; set; }
    }
}
